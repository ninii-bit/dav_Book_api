﻿using BookAPI.IRepository;
using BookAPI.Models;
using BookAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IBookRepository _bookRepository;

        public BooksController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

       
        [HttpGet]
        public ActionResult<IEnumerable<Book>> GetBooks()
        {
            var books = _bookRepository.GetAllBooks();
            return Ok(books);
        }

        
        [HttpGet("{id}")]
        public ActionResult<Book> GetBook(int id)
        {
            var book = _bookRepository.GetBookById(id);
            if (book == null) return NotFound();
            return Ok(book);
        }

        
        [HttpPost]
        public ActionResult<Book> CreateBook(Book book)
        {
            _bookRepository.AddBook(book);
            return Ok(book);
        }

        
        [HttpPut("{id}")]
        public IActionResult UpdateBook(int id, Book book)
        {
            if (id != book.Id) return BadRequest();

            var existingBook = _bookRepository.GetBookById(id);
            if (existingBook == null) return NotFound();

            _bookRepository.UpdateBook(book);
            return Ok();
        }

        
        [HttpDelete("{id}")]
        public IActionResult DeleteBook(int id)
        {
            var book = _bookRepository.GetBookById(id);
            if (book == null) return NotFound();

            _bookRepository.DeleteBook(id);
            return NoContent();
        }
    }
}