﻿using BookAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace BookAPI.Database
{
    public class BookDbContext : DbContext
    {
        public BookDbContext(DbContextOptions<BookDbContext> options) : base(options) { }


        public DbSet<Book> Books { get; set; }
    }
}