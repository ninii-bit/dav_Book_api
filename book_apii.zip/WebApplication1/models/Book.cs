﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookAPI.Models
{
    public class Book
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Title is required")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "title must be between 3 and 100 characters")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Author is required")]
        [MaxLength(50, ErrorMessage = "author name can't be longer than 50 characters")]
        public string Author { get; set; }

        [Range(1, 5000, ErrorMessage = "page count must be between 1 and 5000")]
        public int PageCount { get; set; }

    }
}
